LaTeX styles and model documents of Olivier Bournez.
From https://github.com/nirzolb/SHAREDDIR.git (commit 247aa2c, 2026-10-05).

STYLEDIR/        the styles: macros*.tex, olivier.sty, expose*.sty, beamerthemeVillers.sty
LATEX-EXEMPLES/  the models: tex-minimal.tex (article), expose-minimal.tex (slides),
                 cours-minimal.tex with entete-cours.tex and fin-cours.tex (lecture notes)
exemple.tex      a two-slide test of the styles

To test the bundle, in this directory:
    pdflatex exemple.tex

A document starts with \input{macros} and \input{macros-moins-propres}, without a path:
TeX has to be told where the styles are. From any directory:
    TEXINPUTS=/path/to/READY-TO-COMPILE/STYLEDIR: pdflatex document.tex

Not in this bundle: the bibliography (BIBDESKDIR/@@reference-biblio.bib in the repository)
and the logos that expose-minimal.tex puts on its title page (\FIGCOMMONS).
